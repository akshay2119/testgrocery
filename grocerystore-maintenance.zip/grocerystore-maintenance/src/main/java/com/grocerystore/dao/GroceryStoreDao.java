package com.grocerystore.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.grocerystore.entity.Items;

@Repository
public interface GroceryStoreDao extends CrudRepository<Items, Integer> {

	
}

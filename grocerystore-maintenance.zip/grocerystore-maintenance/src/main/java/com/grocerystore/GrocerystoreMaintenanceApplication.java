package com.grocerystore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import com.grocerystore.entity.Items;
import com.grocerystore.service.GroceryStoreService;

@SpringBootApplication
public class GrocerystoreMaintenanceApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext applicationContext=SpringApplication.run(GrocerystoreMaintenanceApplication.class, args);
		
		GroceryStoreService groceryStoreService=applicationContext.getBean("groceryStoreService",GroceryStoreService.class);
		
		Items item=new Items();
		item.getItemId(1);
		item.getItemName("apple");
		item.getCategory("fruits");
		item.getQuantity(10);
		item.getRate(200);
		
		groceryStoreService.createItems(item);

	
	}

}

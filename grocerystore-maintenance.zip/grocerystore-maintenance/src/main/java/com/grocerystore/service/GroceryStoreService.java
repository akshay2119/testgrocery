package com.grocerystore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.grocerystore.dao.GroceryStoreDao;
import com.grocerystore.entity.Items;

@Service
public class GroceryStoreService {

	@Autowired
	private GroceryStoreDao grocerystoredao;
	
	
	public Items createItems(Items item) {
		// TODO Auto-generated method stub
		return grocerystoredao.save(item);
	}
	
	
	public Items getItemsByid(Integer itemid) {
		// TODO Auto-generated method stub
		return grocerystoredao.findById(itemid).get();
	}


	public Iterable<Items> getAllItems() {
		// TODO Auto-generated method stub
		return grocerystoredao.findAll();
	}


	public Items insertItems(String itemname) {
		// TODO Auto-generated method stub
		return null;
	}


	public void deletItemByid(Integer itemid) {
		// TODO Auto-generated method stub
		grocerystoredao.deleteById(itemid);
	}



	
}

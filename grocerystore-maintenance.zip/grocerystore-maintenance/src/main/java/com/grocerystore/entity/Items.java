package com.grocerystore.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="item")
public class Items {
		@Id
		@Column(name="itemid")
		int itemId;
		
		@Column(name="itemname")
		String itemName;
		
		@Column(name="category")
		String  category;
		
		@Column(name="rate")
		double rate;
		
		@Column(name="quantity")
		int quantity;

		public int getItemId(int itemId) {
			return itemId;
		}

		public void setItemId(int itemId) {
			this.itemId = itemId;
		}

		public String getItemName(String itemname) {
			return itemName;
		}

		public void setItemName(String itemName) {
			this.itemName = itemName;
		}

		public String getCategory(String category) {
			return category;
		}

		public void setCategory(String category) {
			this.category = category;
		}

		public double getRate(int rate) {
			return rate;
		}

		public void setRate(double rate) {
			this.rate = rate;
		}

		public int getQuantity(int quantity) {
			return quantity;
		}

		public void setQuantity(int quantity) {
			this.quantity = quantity;
		}
		
		

}

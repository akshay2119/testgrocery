package com.grocerystore.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.grocerystore.entity.Items;
import com.grocerystore.service.GroceryStoreService;

@RestController
@RequestMapping(value="/grocery")
public class GroceryStoreController {
	@Autowired
	private GroceryStoreService grocerystoreservice; 

	
	@PostMapping(value="/post")
	public Items createItems(@RequestBody Items item) {
		return grocerystoreservice.createItems(item);
	}
	@GetMapping(value="/get")
	public Items getItemsByid(@PathVariable("itemid") Integer itemid) {
	return grocerystoreservice.getItemsByid(itemid);
	}
	
	
	@GetMapping(value="/getall")
	public Iterable<Items> getAllItems(){
	return grocerystoreservice.getAllItems();	
	}
	
	@PutMapping(value="/insert")
	public Items insertItems(@PathVariable("itemname") String itemname,@RequestBody Items item) {
		return grocerystoreservice.insertItems(itemname);
		
	}

	@DeleteMapping(value="/delete")
	public void deleteItemByid(@PathVariable("itemid") Integer itemid) {
		grocerystoreservice.deletItemByid(itemid);
	}
	
}



